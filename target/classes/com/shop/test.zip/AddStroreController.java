package com.shop.test;

import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.shop.controller.common.Pager;
import com.shop.domain.AddStore;
import com.shop.domain.Member;
import com.shop.model.addstore.AddStoreService;

@Controller
public class AddStroreController {
	@Inject
	private AddStoreService addStoreService;
	
	@Inject Pager pager;
	
	
	@RequestMapping(value= "/addStore/list", method=RequestMethod.GET)
	public String adminMain(HttpServletRequest request) {
		return "addStore/index";
	}
	
	@RequestMapping(value="/addStore/regist", method=RequestMethod.POST)
	public ModelAndView regist(Model model, HttpServletRequest request, AddStore addStore) {
	
		HttpSession session=request.getSession();

		Member member = (Member)session.getAttribute("member");
		addStore.setMember(member);
	
		//서비스에게 일시키기 
		List storeList =(List)session.getAttribute("storeList");
			
		addStoreService.regist(storeList, addStore);	
		
		ModelAndView mav = new ModelAndView();
		mav.addObject("url", "/admin/main");
		mav.addObject("msg", "등록 성공");
		mav.setViewName("view/message");
		
		return mav;
	}
	
	@RequestMapping(value="/admin/addStore/list", method=RequestMethod.GET)
	public ModelAndView selectAll(HttpServletRequest request) {
		ModelAndView mav = new ModelAndView();
		
		List storetList = addStoreService.selectAll();
		
		//페이징 처리 객체 
		pager.init(storetList, request);
		mav.addObject("storetList", storetList);
		mav.addObject("pager", pager);
		
		mav.setViewName("admin/addStore/index");
		return mav;
	}
}
