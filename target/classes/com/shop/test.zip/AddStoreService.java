package com.shop.test;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.shop.domain.AddStore;
import com.shop.domain.Member;
import com.shop.exception.DMLException;

@Service
public class AddStoreService {

	@Inject
	private AddStoreDAO addStoreDAO;
	
	
	public void regist(List<Member> memberList,  AddStore addStore) throws DMLException{
		addStoreDAO.insert(addStore);
	}
	
	public List selectAll() {
		return addStoreDAO.selectAll();
	}
}
