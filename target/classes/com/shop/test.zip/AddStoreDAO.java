package com.shop.test;

import java.util.List;

import javax.inject.Inject;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.stereotype.Repository;


import com.shop.domain.AddStore;
import com.shop.exception.DMLException;

@Repository
public class AddStoreDAO {
	@Inject
	private SqlSessionTemplate sessionTemplate;
	
	
	public void insert(AddStore addStore) throws DMLException{
		int result=sessionTemplate.insert("AddStore.insert", addStore);
		if(result==0) {
			throw new DMLException("가맹점이 신청되지 않았습니다");
		}
	}
	
	//모든 상품 가져오기 
	public List selectAll() {
		return sessionTemplate.selectList("AddStore.selectAll");
	}
}
